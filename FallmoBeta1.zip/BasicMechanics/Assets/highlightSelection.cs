﻿using UnityEngine;
using System.Collections;

public class highlightSelection : MonoBehaviour {

	void OnMouseOver(){
		//Change color on hover.
		this.gameObject.renderer.material.color = Color.blue;
	}

	void OnMouseExit(){
		//Return to base color when not hovering.
		this.gameObject.renderer.material.color = Color.white;
	}
}
