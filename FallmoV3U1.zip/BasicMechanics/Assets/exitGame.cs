﻿using UnityEngine;
using System.Collections;

public class exitGame : MonoBehaviour {

	void OnMouseDown(){
		//Quit the game.
		Application.Quit();
	}
}
