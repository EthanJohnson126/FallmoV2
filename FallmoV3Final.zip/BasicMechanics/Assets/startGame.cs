﻿using UnityEngine;
using System.Collections;

public class startGame : MonoBehaviour {

	void OnMouseDown(){
		//Load the first level.
		Application.LoadLevel(1);
	}
}
